<?php
if (!defined('ABSPATH')) {
    exit;
}

function purplebox_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array(
        'height' => 60,
        'width' => 220,
        'flex-height' => true,
        'flex-width' => true,
    ));

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'purplebox-theme'),
        'footer'  => __('Footer Menu', 'purplebox-theme'),
    ));
}
add_action('after_setup_theme', 'purplebox_theme_setup');

function purplebox_theme_scripts() {
    wp_enqueue_style(
        'purplebox-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'purplebox-shared',
        get_template_directory_uri() . '/assets/css/shared.css',
        array('purplebox-fonts'),
        '1.0.0'
    );

    wp_enqueue_style(
        'purplebox-theme',
        get_template_directory_uri() . '/assets/css/theme.css',
        array('purplebox-shared'),
        '1.0.0'
    );

    wp_enqueue_script(
        'purplebox-theme-js',
        get_template_directory_uri() . '/assets/js/theme.js',
        array(),
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'purplebox_theme_scripts');

function purplebox_get_static_file_path($slug) {
    $file_slug = ($slug === 'home' || $slug === '') ? 'index' : $slug;
    $path = get_template_directory() . '/static-html/' . $file_slug . '.html';
    return file_exists($path) ? $path : '';
}

function purplebox_transform_static_links($content) {
    $content = preg_replace_callback('/href="([a-zA-Z0-9\-]+)\.html"/', function ($matches) {
        $slug = sanitize_title($matches[1]);
        if ($slug === 'index') {
            return 'href="' . esc_url(home_url('/')) . '"';
        }
        return 'href="' . esc_url(home_url('/' . $slug . '/')) . '"';
    }, $content);

    $content = str_replace('href="#wa"', 'href="https://wa.me/971542249946" target="_blank" rel="noopener noreferrer"', $content);

    return $content;
}

function purplebox_extract_styles($html) {
    $styles = '';
    $search_pos = 0;
    $lower = strtolower($html);

    while (true) {
        $open = strpos($lower, '<style', $search_pos);
        if ($open === false) {
            break;
        }
        $open_end = strpos($html, '>', $open);
        if ($open_end === false) {
            break;
        }
        $content_start = $open_end + 1;
        $close = strpos($lower, '</style>', $content_start);
        if ($close === false) {
            break;
        }
        $styles .= '<style>' . substr($html, $content_start, $close - $content_start) . '</style>' . "\n";
        $search_pos = $close + 8;
    }

    return $styles;
}

function purplebox_extract_body($html) {
    $lower = strtolower($html);
    $body_open = strpos($lower, '<body');
    if ($body_open === false) {
        return $html;
    }
    $body_start = strpos($html, '>', $body_open);
    if ($body_start === false) {
        return $html;
    }
    $body_start += 1;

    $body_close = strripos($html, '</body>');
    if ($body_close === false) {
        return substr($html, $body_start);
    }

    return substr($html, $body_start, $body_close - $body_start);
}

function purplebox_strip_nested_element($html, $tag, $identifier) {
    $lower = strtolower($html);
    $id_lower = strtolower($identifier);

    $search_pos = 0;
    while (true) {
        $tag_pos = strpos($lower, '<' . $tag, $search_pos);
        if ($tag_pos === false) {
            return $html;
        }
        $tag_end = strpos($html, '>', $tag_pos);
        if ($tag_end === false) {
            return $html;
        }
        $opening = substr($lower, $tag_pos, $tag_end - $tag_pos + 1);
        if (strpos($opening, $id_lower) !== false) {
            break;
        }
        $search_pos = $tag_end + 1;
    }

    $start = $tag_pos;
    $depth = 1;
    $pos = $tag_end + 1;
    $open_tag = '<' . $tag;
    $close_tag = '</' . $tag . '>';
    $len = strlen($html);

    while ($depth > 0 && $pos < $len) {
        $next_open = stripos($html, $open_tag, $pos);
        $next_close = stripos($html, $close_tag, $pos);

        if ($next_close === false) {
            break;
        }

        if ($next_open !== false && $next_open < $next_close) {
            $depth++;
            $pos = $next_open + strlen($open_tag);
        } else {
            $depth--;
            if ($depth === 0) {
                $end = $next_close + strlen($close_tag);
                return substr($html, 0, $start) . substr($html, $end);
            }
            $pos = $next_close + strlen($close_tag);
        }
    }

    return $html;
}

function purplebox_strip_wa_float($html) {
    $lower = strtolower($html);
    $pos = strpos($lower, 'class="wa-float"');
    if ($pos === false) {
        return $html;
    }
    $a_start = strrpos(substr($lower, 0, $pos), '<a');
    if ($a_start === false) {
        return $html;
    }
    $a_end = strpos($lower, '</a>', $pos);
    if ($a_end === false) {
        return $html;
    }
    return substr($html, 0, $a_start) . substr($html, $a_end + 4);
}

function purplebox_get_static_body_content($slug) {
    $path = purplebox_get_static_file_path($slug);
    if (!$path) {
        return '';
    }

    $html = file_get_contents($path);
    if ($html === false) {
        return '';
    }

    $html = ltrim($html, "\xEF\xBB\xBF");

    $styles = purplebox_extract_styles($html);
    $content = purplebox_extract_body($html);

    $content = purplebox_strip_nested_element($content, 'nav', 'class="site-nav"');
    $content = purplebox_strip_nested_element($content, 'div', 'class="mobile-menu"');
    $content = purplebox_strip_nested_element($content, 'footer', 'class="site-footer"');
    $content = purplebox_strip_nested_element($content, 'div', 'class="mobile-cta"');
    $content = purplebox_strip_wa_float($content);

    $content = purplebox_transform_static_links($content);

    return trim($styles . "\n" . $content);
}

function purplebox_render_static_section($slug) {
    $content = purplebox_get_static_body_content($slug);
    if ($content === '') {
        return false;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $content;
    return true;
}

function purplebox_create_default_pages() {
    $static_dir = get_template_directory() . '/static-html';
    if (!is_dir($static_dir)) {
        return;
    }

    $files = glob($static_dir . '/*.html');
    if (!$files) {
        return;
    }

    $template_map = array(
        'about'   => 'page-about.php',
        'contact' => 'page-contact.php',
        'pricing' => 'page-pricing.php',
    );

    $home_page_id = 0;

    foreach ($files as $file) {
        $slug = sanitize_title(basename($file, '.html'));

        if ($slug === 'index') {
            $page_slug = 'home';
            $title = 'Home';
        } else {
            $page_slug = $slug;
            $title = ucwords(str_replace('-', ' ', $slug));
        }

        $existing = get_page_by_path($page_slug, OBJECT, 'page');
        if ($existing) {
            $page_id = (int) $existing->ID;
        } else {
            $page_id = wp_insert_post(array(
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_title'   => $title,
                'post_name'    => $page_slug,
                'post_content' => '',
            ));
        }

        if (!is_wp_error($page_id) && $page_id) {
            if (isset($template_map[$page_slug])) {
                update_post_meta($page_id, '_wp_page_template', $template_map[$page_slug]);
            } elseif ($page_slug !== 'home') {
                update_post_meta($page_id, '_wp_page_template', 'page-static.php');
            }
        }

        if ($page_slug === 'home' && !is_wp_error($page_id) && $page_id) {
            $home_page_id = (int) $page_id;
        }
    }

    if ($home_page_id > 0) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_page_id);
    }
}
add_action('after_switch_theme', 'purplebox_create_default_pages');

function purplebox_maybe_bootstrap_pages() {
    if (get_option('purplebox_pages_bootstrapped') === 'yes') {
        return;
    }

    purplebox_create_default_pages();
    update_option('purplebox_pages_bootstrapped', 'yes');
}
add_action('init', 'purplebox_maybe_bootstrap_pages');
