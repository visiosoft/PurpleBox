﻿<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="pbx-footer-shell" aria-label="Footer">
  <div class="container">
    <div class="pbx-footer">
      <div class="pbx-brand" aria-label="purplebox brand">
        <div class="pbx-brand-logo" aria-hidden="true">P</div>
        <p class="pbx-wordmark">purplebox</p>
      </div>

      <p class="pbx-tagline">Climate-controlled, secure self-storage in Dubai. Personal &amp; business units, packing
        supplies and pickup.</p>

      <section class="pbx-location" aria-label="Facility location">
        <svg class="pbx-map" viewBox="0 0 112 112" role="img"
          aria-label="Stylized mini-map of Dubai with Al Quoz marker" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="pbxSeaGrad" cx="50%" cy="36%" r="70%">
              <stop offset="0%" stop-color="#0d1828" />
              <stop offset="100%" stop-color="#070d18" />
            </radialGradient>
            <filter id="pbxPinShadow" x="-40%" y="-40%" width="180%" height="180%">
              <feDropShadow dx="0" dy="1.4" stdDeviation="1.2" flood-color="#2b175f" flood-opacity="0.7" />
            </filter>
          </defs>
          <rect x="0" y="0" width="112" height="112" fill="url(#pbxSeaGrad)" />
          <path
            d="M81 6 L98 13 L103 25 L95 40 L86 58 L77 68 L69 76 L56 90 L40 100 L26 106 L12 108 L7 94 L11 78 L19 64 L31 53 L42 43 L56 31 L65 22 L74 12 Z"
            fill="#13233a" stroke="rgba(255,255,255,0.12)" stroke-width="0.8" />
          <path d="M19 96 C32 80, 46 64, 62 50 C72 42, 80 34, 90 22" fill="none" stroke="#7c3aed" stroke-width="2.2"
            stroke-linecap="round" stroke-dasharray="4 4" />
          <circle cx="28" cy="28" r="1.2" fill="rgba(255,255,255,0.45)" />
          <circle cx="44" cy="22" r="1" fill="rgba(255,255,255,0.35)" />
          <circle cx="69" cy="34" r="1.1" fill="rgba(255,255,255,0.4)" />
          <circle cx="58" cy="61" r="1.2" fill="rgba(255,255,255,0.5)" />
          <circle cx="36" cy="76" r="1" fill="rgba(255,255,255,0.35)" />
          <g transform="translate(57 57)" filter="url(#pbxPinShadow)">
            <circle cx="0" cy="0" r="4.5" fill="#a78bfa" />
            <path
              d="M0 -7 C3 -7 5.5 -4.7 5.5 -1.8 C5.5 1.5 1.9 5.3 0 8.2 C-1.9 5.3 -5.5 1.5 -5.5 -1.8 C-5.5 -4.7 -3 -7 0 -7 Z"
              fill="#a78bfa" />
            <circle cx="0" cy="0" r="10" fill="none" stroke="#a78bfa" stroke-opacity="0.7" stroke-width="1.2">
              <animate attributeName="r" values="6;17" dur="2s" repeatCount="indefinite" />
              <animate attributeName="stroke-opacity" values="0.65;0" dur="2s" repeatCount="indefinite" />
            </circle>
          </g>
        </svg>

        <div class="pbx-location-meta">
          <p class="pbx-eyebrow">Visit Us</p>
          <p class="pbx-facility">Al Quoz Facility</p>
          <address class="pbx-address">ABA AVENUE - Unit 12 - 12th St - Al Qouz Ind.second - Al Quoz - Dubai</address>
          <p class="pbx-open"><span class="pbx-open-dot" aria-hidden="true"></span>24 Hr open</p>
          <a class="pbx-directions" href="https://maps.google.com/?q=ABA+AVENUE+-+Unit+12+-+12th+St+-+Al+Qouz+Ind.second+-+Al+Quoz+-+Dubai"
            target="_blank" rel="noopener noreferrer">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true">
              <path d="M21 3L11 13" />
              <path d="M21 3L14.5 21L11 13L3 9.5L21 3Z" />
            </svg>
            Directions
          </a>
        </div>
      </section>

      <div class="pbx-link-grid">
        <nav aria-label="Main menu links">
          <p class="pbx-eyebrow">Menu</p>
          <ul>
            <li><a href="<?php echo esc_url(home_url('/book-unit.html')); ?>">Book Unit</a></li>
            <li><a href="<?php echo esc_url(home_url('/store.html')); ?>">Shop Now</a></li>
            <li><a href="<?php echo esc_url(home_url('/packing-moving.html')); ?>">Packing &amp; Moving</a></li>
            <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Community</a></li>
            <li><a href="<?php echo esc_url(home_url('/about.html')); ?>">About</a></li>
          </ul>
        </nav>

        <nav aria-label="Main menu quick links">
          <p class="pbx-eyebrow">Quick Links</p>
          <ul>
            <li><a href="<?php echo esc_url(home_url('/book-unit.html')); ?>">Book Unit</a></li>
            <li><a href="<?php echo esc_url(home_url('/store.html')); ?>">Shop Now</a></li>
            <li><a href="<?php echo esc_url(home_url('/packing-moving.html')); ?>">Packing &amp; Moving</a></li>
            <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Community</a></li>
            <li><a href="<?php echo esc_url(home_url('/about.html')); ?>">About</a></li>
          </ul>
        </nav>
      </div>

      <section class="pbx-contact" aria-label="Inline contact options">
        <a class="pbx-chip" href="tel:80026948">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true">
            <path
              d="M22 16.9V20a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 11.2 18.8A19.5 19.5 0 0 1 5.2 12.8A19.8 19.8 0 0 1 2 4.2A2 2 0 0 1 4 2h3.1a2 2 0 0 1 2 1.7c.1.9.4 1.7.7 2.5a2 2 0 0 1-.4 2.1L8.1 9.6a16 16 0 0 0 6.3 6.3l1.3-1.3a2 2 0 0 1 2.1-.4c.8.3 1.7.6 2.5.7a2 2 0 0 1 1.7 2Z" />
          </svg>
          800-BOX-IT
        </a>
        <a class="pbx-chip" href="mailto:hello@purplebox.ae">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true">
            <rect x="3" y="5" width="18" height="14" rx="2" />
            <path d="M3 8l9 6 9-6" />
          </svg>
          hello@purplebox.ae
        </a>
      </section>

      <section class="pbx-social" aria-label="Social media links">
        <a href="https://www.instagram.com/purpleboxstorage/" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><svg
            viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect x="3" y="3" width="18" height="18" rx="5" />
            <circle cx="12" cy="12" r="4" />
            <circle cx="17.2" cy="6.8" r="1" />
          </svg></a>
        <a href="https://www.facebook.com/profile.php?id=61583010513739#" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><svg viewBox="0 0 24 24"
            fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M14 8h3V4h-3c-3 0-5 2-5 5v3H6v4h3v4h4v-4h3l1-4h-4V9c0-.6.4-1 1-1Z" />
          </svg></a>
        
        <a href="https://wa.me/971542249946" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" style="color:#22c55e;border-color:rgba(34,197,94,0.55);background:rgba(34,197,94,0.12);"><svg
            viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M20 12a8 8 0 0 1-11.8 7l-3.2 1 1-3.1A8 8 0 1 1 20 12Z" />
            <path
              d="M9.5 9.2c.2-.4.5-.4.7-.4h.6c.2 0 .4 0 .6.5.2.4.8 1.7.8 1.8.1.2.1.3 0 .5-.1.2-.2.3-.4.5l-.4.4c-.1.1-.2.2-.1.4.1.2.6 1 1.3 1.6.9.8 1.7 1.1 2 1.2.2.1.3.1.4-.1l.6-.7c.2-.2.3-.2.5-.1s1.5.7 1.7.8c.2.1.4.2.4.3 0 .2-.2.9-.6 1.2-.4.3-1 .4-1.2.4-.3 0-2.8-.8-4.9-2.8-2.4-2.2-2.8-4.5-2.8-4.8 0-.3.1-.8.4-1.1Z" />
          </svg></a>
      </section>

      <div class="pbx-legal">
        <span>&copy; 2026 Short Term Storage L.L.C.</span>
        <div class="pbx-legal-links">
          <a href="<?php echo esc_url(home_url('/privacy.html')); ?>">Privacy</a>
          <span aria-hidden="true">&middot;</span>
          <a href="<?php echo esc_url(home_url('/terms.html')); ?>">Terms</a>
        </div>
      </div>
    </div>
  </div>
</footer>
<a href="https://wa.me/971542249946" class="wa-float" target="_blank" rel="noopener noreferrer">ðŸ’¬</a>
<div class="mobile-cta">
  <a href="https://wa.me/971542249946" class="btn btn-wa btn-full" target="_blank" rel="noopener noreferrer">WhatsApp</a>
  <a href="<?php echo esc_url(home_url('/reserve-step-1.html')); ?>" class="btn btn-primary btn-full">Reserve</a>
</div>
<?php wp_footer(); ?>
</body>
</html>




